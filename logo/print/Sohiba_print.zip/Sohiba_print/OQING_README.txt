SOHIBA — BOSMA UCHUN FAYLLAR (Cosmetolog Sohiba, Urganch)
==========================================================

Barcha fayllar vektor formatda: PDF, SVG va EPS. Yozuvlar konturga
aylantirilgan, shuning uchun bosmaxonada shrift kerak bo'lmaydi.
3D yuz belgisi faylning ichiga yuqori sifatli rasm (300 DPI dan
yuqori) sifatida joylangan. Yassi (bir rangli) belgi esa to'liq vektor.

01_Vizitka
  - vizitka_old_90x50mm / vizitka_orqa_90x50mm — bitta vizitka
    (90x50 mm, har tomondan 2 mm bosma zaxirasi bilan: 94x54 mm)
  - A4_vizitka_old_10ta / A4_vizitka_orqa_10ta — A4 varaqda 10 ta
    (2 ustun x 5 qator), kesish belgilari bilan. Old va orqa tomon
    bir-biriga to'g'ri keladi (ikki tomonlama bosish).
  ! Telefon raqami o'rniga "+998 __ ___ __ __" turibdi — raqamni
    yuboring, qo'yib beraman.

02_Stiker_plomba  (sumkacha og'zini va qutini yopish uchun)
  - stiker_50mm — A4 da 15 ta (3x5)
  - stiker_40mm — A4 da 24 ta (4x6)
  - A4_kesish_chizigi_... — plotter uchun pushti (magenta) kesish
    konturi; stiker varag'i bilan bir xil joylashuvda.
  Tavsiya: yaltiroq (glyanets) yoki matoviy o'z-o'zidan yopishadigan
  qog'oz; tilla rangni folga bilan bosish yanada chiroyli.

03_Yorliq_sumka
  - yorliq_70x35mm — sumkaga yoki qutiga yopishtiriladigan yorliq,
    A4 da 14 ta (2x7), kesish belgilari bilan.

04_Logo  (sumka, quti, banner va vivеska uchun, 120 mm eni,
          istalgan o'lchamga kattalashtiriladi)
  - logo_rangli_oq_fon_uchun — 3D belgi + ko'k yozuv (oq/krem sumka)
  - logo_rangli_kok_fon_uchun — 3D belgi + oq/tilla yozuv (ko'k quti)
  - logo_vektor_kok / tilla / qora / oq — to'liq vektor, bir rangli:
    shtamp, tilla folga, tisneniye, lazer, bir rangli trafaret uchun.

05_Belgi_rasm
  - 3D belgining 4K PNG fayllari (shaffof fon va kulrang fon).

Ranglar: to'q ko'k #1E2A5E, tilla #B8975A / #D9C08C,
         kulrang fon #E4E3E1, matn #4A4542.
Eslatma: ekrandagi va bosmadagi rang biroz farq qiladi — avval bitta
sinov nusxa chiqartirib ko'ring.
